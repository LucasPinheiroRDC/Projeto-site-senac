<?php
    include("conexao.php");

    $nome = $_POST["nome"];
    $raca = $_POST["raca"];
    $idade = $_POST["idade"];
    $links = $_POST["links"];
    
    
    $result_func = "INSERT INTO chinchila(nome, raca, idade, links)
                    VALUES ('$nome','$raca','$idade','$links')";
            
?>
<DOCTYPE! html>

<head>
    <title> Principal | Anidopt </title>
    <link rel="stylesheet" href="Style5.css" type="text/css" />
    <link rel="stylesheet" href="menuresp.css" type="text/css" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
    <link rel="icon" type="imagem/png" href="img/logocortada.png" width="50px" height="50px" />
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="fttas.png" type="image/x-icon">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="imagem/png" href="img/logocortada.png" width="50px" height="50px" />
    <link rel="shortcut icon" href="icons8-poodle-16.png" type="image/x-icon">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style7.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="styles6.css">

    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

        
     <!--Bootstrap Css-->
     <link rel="stylesheet" type="text/css" href="light/kcss/bootstrap.min.css" />

     <!-- Materialdesign icons Css -->
     <link href="light/kcss/materialdesignicons.min.css" rel="stylesheet">

     <!-- Mobirise icons Css -->
     <link href="light/kcss/mobiriseicons.css" rel="stylesheet"> 

     <!-- Magnific-popup -->
     <link rel="stylesheet" href="light/kcss/magnific-popup.css">

     <!-- Animate Css -->
     <link rel="stylesheet" href="light/kcss/animate.min.css">

     <!-- OWL SLIDER -->
     <link rel="stylesheet" href="light/kcss/owl.carousel.css" />
     <link rel="stylesheet" href="light/kcss/owl.theme.css" />
     <link rel="stylesheet" href="light/kcss/owl.transitions.css" />
     <link href="light/kcss/color/default.css" rel="stylesheet" id="option-color">

     <!-- Custom style Css -->
     <link href="light/kcss/style.css" rel="stylesheet">
    
    <style>
        body,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-family: "Lato", sans-serif;
        }

        body,
        html {
            height: 100%;
            color: #777;
            line-height: 1.8;
        }

        /* Create a Parallax Effect */

        .bgimg-1,
        .bgimg-2,
        .bgimg-3 {
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        /* First image (Logo. Full height) */

        .bgimg-1 {
            background-image: url('https://www.w3schools.com/w3images/parallax2.jpg');
            min-height: 100%;
            background: linear-gradient(to right, rgb(54, 186, 191), purple, gold);
            background-size: 400% 400%;
            animation: mygradient 2s ease infinite;
            animation-duration: 30s;
            animation-iteration-count: infinite;
            animation-direction: alternate;
        }

        @keyframes mygradient {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }

        }


        /* Second image (Portfolio) */

        .bgimg-2 {
            background-image: url("https://www.w3schools.com/w3images/parallax2.jpg");
            min-height: 400px;
        }

        /* Third image (Contact) */

        .bgimg-3 {
            background-image: url("https://www.w3schools.com/w3images/parallax3.jpg");
            min-height: 400px;
        }

        .w3-wide {
            letter-spacing: 1px;
        }

        .w3-hover-opacity {
            cursor: pointer;
        }

        @media (max-width:425px) {
            #links {
                margin-left: 15%;
                margin-top: px;
            }
            #logo {
                margin-left: 2%;
                margin-top: 5px;
            }
        }

        @media (max-width:1024px) {
        .site-menu{
            margin-left: -1em;
            margin-top: -1em;
        }
        .mb-0 {
            margin-top: 0.05em;
            margin-left: -1em;
        }
        .controlarindex{
            width: 30em;
            margin-left: 2em;
        }
        .controlardolado{
            width: 25em;
            margin-left: 29em;
            position: absolute;
        }

        }

        /* Turn off parallax scrolling for tablets and phones */

        @media only screen and (max-device-width: 1600px) {

            .bgimg-1,
            .bgimg-2,
            .bgimg-3 {
                background-attachment: scroll;
            }
        }

        .w3-sidebar {
            z-index: 3;
            width: 250px;
            top: 43px;
            bottom: 0;
            height: inherit;
        }

        /*Slider*/

        #slider {
            overflow: hidden;
        }

        #slider figure {
            position: relative;
            width: 625%;
            margin: 0;
            left: 0;
            animation: 15s slider infinite;
        }

        #slider figure img {
            width: 16%;
            float: left;
        }

        @keyframes slider {
            0% {
                left: 0;
            }
            20% {
                left: 0;
            }
            25% {
                left: -100%;
            }
            45% {
                left: -100%;
            }
            50% {
                left: -200%;
            }
            70% {
                left: -200%;
            }
            75% {
                left: -300%;
            }
            95% {
                left: -300%;
            }
            100% {
                left: -400%;
            }
        }

    </style>
</head>

<body>

<div class="bgimg-1 w3-display-container w3-opacity-min" id="home">
    <div class="w3-display-middle" style="white-space:nowrap;">
        <span class="w3-center w3-padding-large w3-black w3-xlarge w3-wide w3-animate-opacity"> <?php  $resultado_func = mysqli_query($conn, $result_func);
   
   if(mysqli_affected_rows($conn) != 0){
               echo "Animal cadastrado com sucesso! <a href=\"painel.php\">clique aqui para voltar</a>";
           }else{
               echo "Erro ao cadastrar";

                
           } ?>
           <span class="w3-hide-small"></span>
        </span>
    </div>
</div>

</div>



        </body>

        </html>