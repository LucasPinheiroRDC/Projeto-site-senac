<?php
include("conexao.php");
$id = $_GET["id"];
$mysqli = new mysqli("localhost","root","","progweb");

$mysqli -> query("SELECT * FROM chinchila");
echo "Total de registros encontrados: " . $mysqli -> affected_rows;

$mysqli -> query("DELETE FROM chinchila WHERE id = $id");
echo "<br> Total de registros excluídos: " . $mysqli -> affected_rows;

$mysqli -> close();
?>
