<?php

  include("conexao.php");

  echo pathinfo("", PATHINFO_EXTENSION);

  if(isset($_FILES['arquivo'])){
    $arquivo = $_FILES['arquivo'];

    if($arquivo['error'])
      die("Falha ao enviar arquivo"); 

    if($arquivo['size'] > 2097152)
      die("Arquivo muito grande!! Max: 2MB");


    $pasta = "arquivos/";
    $nomeDoArquivo = $arquivo['name'];
    $novoNomeDoArquivo = uniqid();
    $extensao = strtolower(pathinfo($nomeDoArquivo, PATHINFO_EXTENSION)); 

    if($extensao != "jpg" && $extensao != 'png')
      die("Tipo de arquivo não aceito");


    $path = $pasta . $novoNomeDoArquivo . "." . $extensao;
    $deu_certo = move_uploaded_file($arquivo["tmp_name"], $path);
      if($deu_certo){
        $mysqli ->query ("INSERT INTO arquivo (nome, path) VALUES('nomeDoArquivo','path')") or die($mysqli->error);

       echo "<p>Arquivo enviado com sucesso!</p>";
      }
      else
        echo "<p> Falha ao enviar arquivo </p>"

    
  }

?>
<h1>Upload de Arquivos</h1>
<?php if(isset($msg) && $msg != false) echo "<p> $msg </p>"; ?>
<form action="upload.php" method="POST" enctype="multipart/form-data">
  Arquivo: <input type="file" required name="arquivo">
  <input type="submit" value="Salvar">
</form>