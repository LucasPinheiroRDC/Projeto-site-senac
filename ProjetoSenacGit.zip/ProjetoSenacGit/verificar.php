<?php
session_start();

// Verifique se o usuário está autenticado
if (!isset($_SESSION['nome'])) {
    // Se o usuário não estiver autenticado, redirecione-o para a página de login
    header('Location: login.php');
    exit;
}

// Se o usuário estiver autenticado, mostre a página de perfil
echo '' . $_SESSION['nome'] . '! <p><a href="painel.php">(Retornar)</a></p>';
?>
