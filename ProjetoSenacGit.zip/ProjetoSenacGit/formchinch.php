<?php session_start(); 
include("conexao.php");

?>
<DOCTYPE html>
    <html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Cadastro de Chinchila</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="forminstcod.css">
    </head>

    <body>

        <div class="registration-form">
            
            <form action="salvarchinch.php" method="post">

                <section class="get-in-touch">
                    <h1 class="title">Chinchilas 
                <?php
    echo"".$_SESSION["nome"];
    ?></h1>
                </section>


                <div class="form-group">
                    <input type="text" class="form-control item" name="nome" placeholder="Nome do animal">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control item" name="raca" placeholder="Raça">
                </div>
               
                <div class="form-group">
                    <input type="text" class="form-control item" name="idade" placeholder="Idade">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control item" name="links" placeholder="Link da Publicação">
                </div>
               
                <div class="form-group">
                   <input class="btn btn-block create-account" type="submit" name="submit" value="Registrar" /> 
                </div>
                
                
                
            </form>
            
            </div>
        </div>
    
    </body>

    </html>