<DOCTYPE html>
    <html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Cadastro de Instituição</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="forminstcod.css">
    </head>

    <body>

        <div class="registration-form">
            
            <form action="formanimais.php" method="post">

                <section class="get-in-touch">
                    <h1 class="title">Cadastro do animal</h1>
                </section>

                <div class="form-group">
                    <input type="text" class="form-control item" id="nome" placeholder="Nome do animal">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control item" id="raca" placeholder="Raça">
                </div>
               
                <div class="form-group">
                    <input type="text" class="form-control item" id="idade" placeholder="Idade">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control item" id="Link" placeholder="Link da Publicação">
                </div>

                <div class="flex w-full h-screen items-center justify-center bg-grey-lighter">
    <label class="w-64 flex flex-col items-center px-4 py-6 bg-white text-blue rounded-lg shadow-lg tracking-wide uppercase border border-blue cursor-pointer hover:bg-blue hover:text-white">
        <span class="mt-2 text-base leading-normal">Foto do animal</span>
        <input type='file' class="hidden" />
    </label>
</div>
               
                <div class="form-group">
                    <button type="button" class="btn btn-block create-account">Cadastrar</button>
                </div>
            </form>
           
        </div>
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
        <script src="assets/js/formlogin.js"></script>
    </body>

    </html>