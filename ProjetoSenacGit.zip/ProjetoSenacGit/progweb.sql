-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 12-Nov-2022 às 01:04
-- Versão do servidor: 10.1.39-MariaDB
-- versão do PHP: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `progweb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aves`
--

CREATE TABLE `aves` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cachorros`
--

CREATE TABLE `cachorros` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `chinchila`
--

CREATE TABLE `chinchila` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `coelho`
--

CREATE TABLE `coelho` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `furao`
--

CREATE TABLE `furao` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `gatos`
--

CREATE TABLE `gatos` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `hamster`
--

CREATE TABLE `hamster` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `instituicao`
--

CREATE TABLE `instituicao` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `cep` varchar(9) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `cel` varchar(13) DEFAULT NULL,
  `data_cri` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `patos`
--

CREATE TABLE `patos` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `peixes`
--

CREATE TABLE `peixes` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `porcos`
--

CREATE TABLE `porcos` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tartaruga`
--

CREATE TABLE `tartaruga` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aves`
--
ALTER TABLE `aves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cachorros`
--
ALTER TABLE `cachorros`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chinchila`
--
ALTER TABLE `chinchila`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coelho`
--
ALTER TABLE `coelho`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `furao`
--
ALTER TABLE `furao`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gatos`
--
ALTER TABLE `gatos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hamster`
--
ALTER TABLE `hamster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instituicao`
--
ALTER TABLE `instituicao`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patos`
--
ALTER TABLE `patos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `peixes`
--
ALTER TABLE `peixes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `porcos`
--
ALTER TABLE `porcos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tartaruga`
--
ALTER TABLE `tartaruga`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aves`
--
ALTER TABLE `aves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cachorros`
--
ALTER TABLE `cachorros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chinchila`
--
ALTER TABLE `chinchila`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coelho`
--
ALTER TABLE `coelho`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `furao`
--
ALTER TABLE `furao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gatos`
--
ALTER TABLE `gatos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hamster`
--
ALTER TABLE `hamster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `instituicao`
--
ALTER TABLE `instituicao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patos`
--
ALTER TABLE `patos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `peixes`
--
ALTER TABLE `peixes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `porcos`
--
ALTER TABLE `porcos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tartaruga`
--
ALTER TABLE `tartaruga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
