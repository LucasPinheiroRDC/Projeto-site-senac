<?php
  //Variáveis
  $nomeinst = $_POST['nome'];
  $emailinst = $_POST['email'];
  $linkinst = $_POST['linkinst'];

  //Compo E-mail
  $arquivo = "
    <html>
      <p><b>Nome: </b>$nomeinst</p>
      <p><b>E-mail: </b>$emailinst</p>
      <p><b>Mensagem: </b>$linkinst</p>
    </html>
  ";
  
  //Emails para quem será enviado o formulário
  $destino = "itslucasprc@gmail.com";
  $assunto = "Contato da Anydopt";

  //Este sempre deverá existir para garantir a exibição correta dos caracteres
  $headers  = "MIME-Version: 1.0\n";
  $headers .= "Content-type: text/html; charset=iso-8859-1\n";
  $headers .= "From: $nomeinst <$emailinst>";

  //Enviar
  mail($destino, $assunto, $arquivo, $headers);
  
  echo "<meta http-equiv='refresh' content='10;URL=../contato.html'>";
?>