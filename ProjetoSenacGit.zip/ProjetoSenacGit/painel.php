<?php session_start(); 
include("conexao.php");

?>
<html>
    <head>
        <meta charset="utf-8">
        <title> Painel de Controle </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="Style5.css" type="text/css" />
        <link rel="stylesheet" href="Styles6.css">
        <!--Bootstrap Css-->
		 <link rel="stylesheet" type="text/css" href="light/kcss/bootstrap.min.css" />



        <style>
            #total{
                background:#38B6FF;
            }
            body,
			html {
				height: 100%;
				color: #777;
				line-height: 1.8;
			}
        </style>
    </head>

    <body>

        <div id = "total">

               <center><img src="Anydopt.png" width="250" height="200">
</center> 

</div>          
<hr>
<div id="conteudo">

		<div class="poster">

		<?php
    echo"Seja Bem vindo! ".$_SESSION["nome"];
    ?>

			<h2 style="margin-left:2%;">Cadastrar</h2>

			<div class="poster-main" style="margin-left:3%;">
				<div class="poster-list">
	<a href="formturtle.php"><img src="Cachorroad01.jpg" loading="lazy" alt="Taylor" /></a>
					<div class="ASCNP">

						<h3> Cachorros </h3>

					</div>
				</div>
				<div class="poster-list" style="margin-bottom: 3%;">
	<a href="formcat.php"><img src="Gatsadpt.jpg" loading="lazy" alt="hafizh armynazrie" /></a>
					<div class="ASCNP">

						<h3> Gatos </h3>

					</div>
				</div>
				<div class="poster-list">
	<a href="formrabbit.php"><img src="coelho.jpg" loading="lazy" alt="Curtis Potvin" /></a>
					<div class="ASCNP">

						<h3> Coelhos </h3>

					</div>
				</div>
			
		

				<div class="poster-list">
	<a href="formturtle.php"><img src="Tartgs.jpg" loading="lazy" alt="Joshua Hanson" /></a>
					<div class="ASCNP">

						<h3> Tartaruga </h3>

					</div>
				</div>


				<div class="poster-list">
	<a href="formaves.php"><img src="passros.jpg" loading="lazy" alt="Music HQ" /></a>
					<div class="ASCNP">

						<h3> Aves </h3>

					</div>
				</div>

				<div class="poster-list">
	<a href="formchinch.php"><img src="chinchl.jpg" loading="lazy" alt="Music HQ" /></a>
					<div class="ASCNP">

						<h3> Chinchila </h3>

					</div>
				</div>


				<div class="poster-list">
<a href="formfish.php"><img src="pxsadpt.jpg" loading="lazy" alt="Animal" /></a>
					<div class="ASCNP">

						<h3> Peixes </h3>

					</div>
        </div>

        <div class="poster-list">
        <a href="logout.php"><img src="imgestp/voltaire.png" loading="lazy" alt="Animal"> </a>
					<div class="ASCNP">
                     <h3> Sair </h3>
                    </div>

                    </div>
			</div>
		</div>
	</div>
       
        
            <p>&nbsp;</p>


<div id="rodape">

    <div id="r1">

    </div>

    <div id="r2">
        <div id="txt">
            <br>
            <p>Contatos
                <br>

                <h3>Anidopt - Lar Para Todos
                    <br> Tel (21) 5725-4222</h3>
                </div>

                <li>
                    <img src="wpp.png" width="26px" height="26px">
                    <img src="inst.jpg" width="26px" height="26px">
                    <img src="fcb.png" width="26px" height="26px">
                    <img src="gm.png" width="26px" height="26px">
                </li>

            </div>

            <div id="r3">
                <font face="Roboto" color="#808080">
                    <p>Desenvolvido por Anydopt. © Copyright 2020; Todos os direitos reservados </font>
                    </div>


                </div>
  


</body>
</html>