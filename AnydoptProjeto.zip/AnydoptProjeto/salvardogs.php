<?php
    include("conexao.php");

    $nome = $_POST["nome"];
    $raca = $_POST["raca"];
    $idade = $_POST["idade"];
    $links = $_POST["links"];
    
    
    $result_func = "INSERT INTO cachorros(nome, raca, idade, links)
                    VALUES ('$nome','$raca','$idade','$links')";
    $resultado_func = mysqli_query($conn, $result_func);
   
    if(mysqli_affected_rows($conn) != 0){
                echo "Animal cadastrado com sucesso,<p><a href=\"painel.html\">clique aqui para voltar</a></p>";
            }else{
                echo "Erro ao cadastrar";

                 
            }
            
?>