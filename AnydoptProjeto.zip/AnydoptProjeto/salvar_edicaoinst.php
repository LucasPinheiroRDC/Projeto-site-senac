
<?php

include("conexao.php");
$id = $_POST["id"];
$nome = $_POST["nome"];
$cep = $_POST["cep"];
$email = $_POST["email"];
$cel = $_POST["cel"];
$data_cri= $_POST["data_cri"];


$sql = "UPDATE cliente SET nome = '$nome', cep = '$cep',email = '$email',
cel = '$cel', data_cri = '$data_cri' WHERE cliente.id = '$id'";

$query = mysqli_query($conn, $sql);

header("Location: listarinst.php");
?>
