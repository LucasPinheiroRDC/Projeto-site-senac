<?php session_start(); ?>
<html>
    <head>
        <meta charset="utf-8">
        <title> Painel de Controle </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="Style5.css" type="text/css" />

        <style>

             @media (max-width:320px) {
                #rodape{
                  position: absolute;
                  width: 100%;
                  height: auto;
                  float: left;
                  margin-top: 63em;
                }
            }

           @media (max-width:425px) {
                #funcoes{
                    float: left;
                    margin-left: -10em;
                    padding-bottom: 20px;
                }
            }

            

            #total{
                background:rgb(55, 186, 185)
            }
            #funcoes{
                width: 100%;
                float: left;
            }

            #ico1, #ico2, #ico3{
                width: 210px;
                float: left; 
                margin-left: 180px;
                margin-top: 20px;
                border-spacing: 30px;
                font-family: Tahoma;
                padding-bottom: 20px;

                
                
            }
        </style>
    </head>

    <body>
        <div id = "total">

               <center><img src="Anilogotipo.png" width="250" height="200">
</center> 
               <hr>

               <div id="funcoes">
                              <?php
    echo"Seja Bem vindo! ".$_SESSION["nome"];
    ?>
                    
                    <div id="ico1">

                        <a href="formaves.html"><img src="imgestp/passaro.jpg" width="100" height="100"> </a>

                        <a href="listaraves.php"><img src="imgestp/listarar.png" width="100" height="100"> </a>
                    <br><center> Ave | Listar </center>
                    </div>

                    <div id="ico2">
                        <a href="formdogs.html"><img src="imgestp/cachro.png" width="100" height="100"> </a>
                        <a href="listardogs.php"><img src="imgestp/listarar.png" width="100" height="100"> </a>
                        <br> <center>Cachorro | Listar </center>
                    </div>

                     <div id="ico2">
                        <a href="formchinch.html"><img src="imgestp/chincho.png" width="100" height="100"> </a>
                        <a href="listarchinch.php"><img src="imgestp/listarar.png" width="100" height="100"> </a>
                        <br> <center> Chinchila | Listar </center>
                    </div>

                     <div id="ico2">
                        <a href="formrabbit.html"><img src="imgestp/cueio.png" width="100" height="100"> </a>
                        <a href="listarrabbit.php"><img src="imgestp/listarar.png" width="100" height="100"> </a>
                        <br> <center> Coelho | Listar </center>
                    </div>


 <div id="ico2">
                        <a href="formcat.html"><img src="imgestp/gato.png" width="100" height="100"> </a>
                        <a href="listarcat.php"><img src="imgestp/listarar.png" width="100" height="100"> </a>
                        <br> <center> Gato | Listar </center>
                    </div>


 <div id="ico2">
                        <a href="formfish.html"><img src="imgestp/peixe.png" width="100" height="100"> </a>
                        <a href="listarfish.php"><img src="imgestp/listarar.png" width="100" height="100"> </a>
                        <br> <center> Peixe | Listar </center>
                    </div>


 <div id="ico2">
                        <a href="formturtle.html"><img src="imgestp/tart.png" width="100" height="100"> </a>
                        <a href="listarturtle.php"><img src="imgestp/listarar.png" width="100" height="100"> </a>
                        <br> <center> Tartaruga | Listar </center>
                    </div>

                         <div id="ico2">
                        <a href="index2.html"><img src="imgestp/voltaire.png" width="200" height="100"> </a>
                        <br> <center> Sair </center>
                    </div>
   

                </div>

            </div>
            <p>&nbsp;</p>


<div id="rodape">

    <div id="r1">

    </div>

    <div id="r2">
        <div id="txt">
            <br>
            <p>Contatos
                <br>

                <h3>Anidopt - Lar Para Todos
                    <br> Tel (21) 5725-4222</h3>
                </div>

                <li>
                    <img src="wpp.png" width="26px" height="26px">
                    <img src="inst.jpg" width="26px" height="26px">
                    <img src="fcb.png" width="26px" height="26px">
                    <img src="gm.png" width="26px" height="26px">
                </li>

            </div>

            <div id="r3">
                <font face="Roboto" color="#808080">
                    <p>Desenvolvido por Hypertech. © Copyright 2020; Todos os direitos reservados </font>
                    </div>


                </div>
  


</body>
</html>