<?php

include("conexao.php");

$id = $_POST["id"];
$nome = $_POST["nome"];
$idade = $_POST["idade"];
$raca = $_POST["raca"];
$links = $_POST["links"];


$sql = "UPDATE chinchila SET nome = '$nome', idade = '$idade',
raca = '$raca' WHERE chinchila.id = '$id'";

$query = mysqli_query($conn, $sql);

header("Location: listarchinch.php");
?>
