
<?php
include("conexao.php");
$id = $_GET["id"];
settype($id, "integer");

$sql = "select * from tartaruga where id = $id";
$query = mysqli_query($conn, $sql);
$dados  = mysqli_fetch_array($query);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta charset="utf-8">
 <html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Atualizar Dados do Animal</title>
</head>

<body>

<form id="form1" name="form1" method="post" action="salvar_edicaoturtle.php">

<input type="hidden" name="id" id="id" value="<?php echo $id;?>" />

  <h2 align="center"><strong>Edição de Cadastro de Animal </strong></h2>

  <table width="390" border="1" align="center">

    <tr>
      <td width="165">Nome</td>
      <td width="209"><input name="nome" type="text" id="nome" value="<?php echo $dados["nome"];?>" /></td>
    </tr>

    <tr>
      <td>Raça</td>
      <td><input name="raca" type="text" id="raca" value="<?php echo $dados["raca"];?>" /></td>
    </tr>

     <tr>
      <td>idade</td>
      <td><input name="idade" type="text" id="idade" value="<?php echo $dados["idade"];?>" /></td>
    </tr>

	<tr>
      <td>link</td>
      <td><input name="links" type="text" id="links" value="<?php echo $dados["links"];?>" /></td>
    </tr>
<tr>
    <td>&nbsp;</td> 
    <td><input type="submit" name="Submit" value="Gravar" 
      style:"cursor:pointer" /><td>
</tr>

   </table>
  </form>
 </body>
</html>