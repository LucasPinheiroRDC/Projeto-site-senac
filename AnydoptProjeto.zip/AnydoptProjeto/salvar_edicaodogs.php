<?php

include("conexao.php");

$id = $_POST["id"];
$nome = $_POST["nome"];
$idade = $_POST["idade"];
$raca = $_POST["raca"];
$links = $_POST["links"];


$sql = "UPDATE cachorros SET nome = '$nome', idade = '$idade',
raca = '$raca' WHERE cachorros.id = '$id'";

$query = mysqli_query($conn, $sql);

header("Location: listardogs.php");
?>
