<?php
include("conexao.php")
?>



<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title> AnyDopt - Entrar </title>
		<meta charset="UTF-8" />
		<!-- Estilos da Index.php -->
		<style type="text/css">
			body{
    		background-color: #dee9ff;
			font-family: Tahoma;
			}

			div.global{
			 background-color: #fff;
    		max-width: 400px;
    		margin: auto;
    		padding: 50px 70px;
   	 		border-top-left-radius: 30px;
    		border-top-right-radius: 30px;
    		border-bottom-left-radius: 30px;
    		border-bottom-right-radius: 30px;
    		box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.075);
    		margin-top: 10em;

			}
			input[type='text'], input[type='password']{
			width: 250px;
			height: 25px;
			border: solid 1px #606060;
			border-radius: 5px;
			border-radius: 20px;
   			padding: 10px 20px;
   			margin-left: 2em;
}
			}
			input[type='password']{
			margin-left: 10px;
			}
			
			input[type='submit']{
			width: 150px; 
			border-radius: 30px;
    		padding: 10px 20px;
    		font-size: 18px;
   			font-weight: bold;
   			background-color: #5791ff;
    		border: none;
    		color: white;
    		margin-top: 20px;
    		margin-left: 7em;i
			}
			.get-in-touch .title {
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 3px;
    font-size: 3.2em;
    line-height: 48px;
    font-size: 50px;
    padding-bottom: 10px;
       color: #5543ca;
      background: #5543ca;
      background: -moz-linear-gradient(left,#f4524d  0%,#5543ca 100%) !important;
      background: -webkit-linear-gradient(left,#f4524d  0%,#5543ca 100%) !important;
      background: linear-gradient(to right,#f4524d  0%,#5543ca  100%) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
  }
		</style>
	</head>
	<body>
	
		<div class="global">
		<form action="verificarlogin.php" method="post">

				 <section class="get-in-touch">
                    <h1 class="title"> Entrar </h1>
                </section>


				<label>Email: <input type="text" name="email" placeholder="E-mail" /></label><br /><br />

				<label>Senha: <input type="password" name="senha" placeholder="Senha" /></label><br /><br />

				<input type="submit" name="submit" value="Logar" /> 

			</form>
		</div>
	</body>
</html>			