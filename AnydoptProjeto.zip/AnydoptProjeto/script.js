
function openNav(){
	document.getElementByid("myNav").openNav.width = "100%";
}

function closeNav(){
	document.getElementByid("myNav").closeNav.width = "0%";
}