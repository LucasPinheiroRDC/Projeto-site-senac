<!-- INÍCIO DOS MENUS -->
<!-- MENU 1 -->
<?php if($_SESSION['nivel'] == 1) { ?>

<input type="checkbox" id="bt_menu1">
    <label for="bt_menu1">&#9776;</label>
    <nav class="menu1">
        <ul>
            <li><a href="#"><strong>Estatutos</strong></a>
            <ul>
            <li><a href="metas.php"><strong>Metas</strong></a></li>
            <li><a href="rd.php"><strong>Regulamento Disciplinar</strong></a></li>
            <li><a href="pet.php"><strong>Regimento Interno</strong></a></div></li>
        </ul>
    </li>
    <li><a href="#"><strong>Consultar</strong></a>
            <ul>
            <li><a href="listar_funcionarios_equipe.php"><strong>Consultar Funcionários</strong></a></li>
        </ul>
    </li>
    <li><a href="logout.php"><strong><font color="red">S a i r</font></strong></a>
    </li>

        </ul>
    </nav>
    <?php } ?>
<!-- MENU 2 -->
<?php if($_SESSION['nivel'] == 2) { ?>

<input type="checkbox" id="bt_menu1">
    <label for="bt_menu1">&#9776;</label>
    <nav class="menu1">
        <ul>
            <li><a href="#"><strong>Estatutos</strong></a>
            <ul>
            <li><a href="metas.php"><strong>Metas</strong></a></li>
            <li><a href="rd.php"><strong>Regulamento Disciplinar</strong></a></li>
            <li><a href="pet.php"><strong>Regimento Interno</strong></a></div></li>
        </ul>
    </li>
    <li><a href="#"><strong>Consultar</strong></a>
            <ul>
                <li><a href="listar_funcionarios_promover.php"><strong>Consultar Funcionários</strong></a></li>
                <li><a href="listartreinamento_equipe.php"><strong>Listar Treinamento</strong></a></li>
        </ul>
    </li>
    <li><a href="#"><strong>Atividades</strong></a>
        <ul>
        <li><a href="listar_funcionarios_promover.php"><strong>Promover</strong></a></li>
        <li><a href="treinamento.php"><strong>Aplicar Treinamento</strong></a></li>
        <li><a href="funcionario.php"><strong>Contratar</strong></a></li>

    </ul>
</li>
<li><a href="logout.php"><strong><font color="red">S a i r</font></strong></a>
</li>
        </ul>
    </nav>
    <?php } ?>
<!-- MENU 3 -->
<?php if($_SESSION['nivel'] == 3) { ?>
    <input type="checkbox" id="bt_menu1">
    <label for="bt_menu1">&#9776;</label>
    <nav class="menu1">
        <ul>
            <li><a href="#"><strong>Estatutos</strong></a>
            <ul>
            <li><a href="metas.php"><strong>Metas</strong></a></li>
            <li><a href="rd.php"><strong>Regulamento Disciplinar</strong></a></li>
            <li><a href="pet.php"><strong>Regimento Interno</strong></a></div></li>
        </ul>
    </li>
    <li><a href="#"><strong>Consultar</strong></a>
            <ul>
                <li><a href="listar_funcionarios_promover.php"><strong>Consultar Funcionários</strong></a></li>
                <li><a href="listartreinamento3.php"><strong>Listar Treinamento</strong></a></li>
        </ul>
    </li>
    <li><a href="#"><strong>Atividades</strong></a>
        <ul>
        <li><a href="listar_funcionarios_promover.php"><strong>Promover</strong></a></li>
        <li><a href="treinamento.php"><strong>Aplicar Treinamento</strong></a></li>
        <li><a href="funcionario.php"><strong>Contratar</strong></a></li>
        <li><a href="acesso.php"><strong>Controle de Acesso</strong></a></li>

    </ul>
</li>
<li><a href="logout.php"><strong><font color="red">S a i r</font></strong></a>
</li>
        </ul>
    </nav>
    <?php } ?>
    
<!-- MENU 4 -->
<?php if($_SESSION['nivel'] == 4) { ?>
    <input type="checkbox" id="bt_menu1">
    <label for="bt_menu1">&#9776;</label>
    <nav class="menu1">
        <ul>
            <li><a href="#"><strong>Estatutos</strong></a>
            <ul>
            <li><a href="metas.php"><strong>Metas</strong></a></li>
            <li><a href="rd.php"><strong>Regulamento Disciplinar</strong></a></li>
            <li><a href="pet.php"><strong>Regimento Interno</strong></a></div></li>
        </ul>
    </li>
    <li><a href="#"><strong>Consultar</strong></a>
            <ul>
                <li><a href="listar_funcionarios_promover.php"><strong>Consultar Funcionários</strong></a></li>
                <li><a href="listartreinamento3.php"><strong>Listar Treinamento</strong></a></li>
        </ul>
    </li>
    <li><a href="#"><strong>Atividades</strong></a>
        <ul>
        <li><a href="listar_funcionarios_promover.php"><strong>Promover</strong></a></li>
        <li><a href="treinamento.php"><strong>Aplicar Treinamento</strong></a></li>
        <li><a href="funcionario.php"><strong>Contratar</strong></a></li>
        <li><a href="acesso.php"><strong>Controle de Acesso</strong></a></li>
        <li><a href="nivel.php"><strong>Sistema de Níveis</strong></a></li>

    </ul>
</li>
<li><a href="logout.php"><strong><font color="red">S a i r</font></strong></a>
</li>
        </ul>
    </nav>
    <?php } ?>
    <!-- MENU 5 -->
<?php if($_SESSION['nivel'] == 5) { ?>
    <input type="checkbox" id="bt_menu1">
    <label for="bt_menu1">&#9776;</label>
    <nav class="menu1">
        <ul>
            <li><a href="#"><strong>Estatutos</strong></a>
            <ul>
            <li><a href="metas.php"><strong>Metas</strong></a></li>
            <li><a href="rd.php"><strong>Regulamento Disciplinar</strong></a></li>
            <li><a href="pet.php"><strong>Regimento Interno</strong></a></div></li>
        </ul>
    </li>
    <li><a href="#"><strong>Consultar</strong></a>
            <ul>
                <li><a href="listar_funcionarios_promover.php"><strong>Consultar Funcionários</strong></a></li>
                <li><a href="listartreinamento3.php"><strong>Listar Treinamento</strong></a></li>
        </ul>
    </li>
    <li><a href="#"><strong>Atividades</strong></a>
        <ul>
        <li><a href="listar_funcionarios_promover.php"><strong>Promover</strong></a></li>
        <li><a href="listar_funcionarios.php"><strong>Edição de Cadastro</strong></a></li>
        <li><a href="treinamento.php"><strong>Aplicar Treinamento</strong></a></li>
        <li><a href="funcionario.php"><strong>Contratar</strong></a></li>
        <li><a href="acesso.php"><strong>Controle de Acesso</strong></a></li>
        <li><a href="nivel.php"><strong>Sistema de Níveis</strong></a></li>

    </ul>
</li>
<li><a href="logout.php"><strong><font color="red">S a i r</font></strong></a>
</li>
        </ul>
    </nav>
    <?php } ?>

<!--  FIM DOS MENUS -->