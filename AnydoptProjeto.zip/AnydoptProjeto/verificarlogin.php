<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
   
    <?php  
    // pegar os dados da tela
    
    $email = $_POST["email"]; //geann
    $senha =($_POST["senha"]); //123

    // Fazer a conexão com o banco
    $con = mysqli_connect("localhost","root","","progweb");

    // montar a instrução para consultar se existe este usuário no banco
    $sql = "select * from instituicao where email = '".$email."' and senha = '".$senha."'";
 
    $result = mysqli_query($con,$sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result);
        $_SESSION["nome"] = $row["nome"];
        $_SESSION["tempo"] = time();
        header("Location:painel.php");
    } else {
        echo " Email ou senha Invalido!";
    }
    
    
    
    ?>
</body>
</html>