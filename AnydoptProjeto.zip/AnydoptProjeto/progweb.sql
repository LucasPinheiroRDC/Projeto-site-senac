-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24-Fev-2023 às 21:58
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `progweb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aves`
--

CREATE TABLE `aves` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `links` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Extraindo dados da tabela `aves`
--

INSERT INTO `aves` (`id`, `nome`, `raca`, `idade`, `links`) VALUES
(1, 'chico', 'rapina', 15, 'agumlink.com.br'),
(2, 'eualibaba', 'rapina', 15, 'agumlink.com.br');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cachorros`
--

CREATE TABLE `cachorros` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `links` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `chinchila`
--

CREATE TABLE `chinchila` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `links` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `coelho`
--

CREATE TABLE `coelho` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `links` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `contatos`
--

CREATE TABLE `contatos` (
  `id` int(11) NOT NULL,
  `nomeinst` varchar(50) DEFAULT NULL,
  `emailinst` varchar(50) DEFAULT NULL,
  `linkinst` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `contatos`
--

INSERT INTO `contatos` (`id`, `nomeinst`, `emailinst`, `linkinst`) VALUES
(1, '', '', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `furao`
--

CREATE TABLE `furao` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `gatos`
--

CREATE TABLE `gatos` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `links` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `hamster`
--

CREATE TABLE `hamster` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `links` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `instituicao`
--

CREATE TABLE `instituicao` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `senha` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Extraindo dados da tabela `instituicao`
--

INSERT INTO `instituicao` (`id`, `nome`, `email`, `senha`) VALUES
(1, 'eualibaba', 'eualibaba@gmail.com', 'alibaba'),
(2, 'chico', 'eualibabachaco@gmail.com', 'dara'),
(3, '', '', ''),
(4, 'Lucas Pinheio', 'LucasP', 'Lukinhaz');

-- --------------------------------------------------------

--
-- Estrutura da tabela `patos`
--

CREATE TABLE `patos` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `peixes`
--

CREATE TABLE `peixes` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `links` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `porcos`
--

CREATE TABLE `porcos` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tartaruga`
--

CREATE TABLE `tartaruga` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `links` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `aves`
--
ALTER TABLE `aves`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `cachorros`
--
ALTER TABLE `cachorros`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `chinchila`
--
ALTER TABLE `chinchila`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `coelho`
--
ALTER TABLE `coelho`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `contatos`
--
ALTER TABLE `contatos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `furao`
--
ALTER TABLE `furao`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `gatos`
--
ALTER TABLE `gatos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `hamster`
--
ALTER TABLE `hamster`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `instituicao`
--
ALTER TABLE `instituicao`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `patos`
--
ALTER TABLE `patos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `peixes`
--
ALTER TABLE `peixes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `porcos`
--
ALTER TABLE `porcos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tartaruga`
--
ALTER TABLE `tartaruga`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aves`
--
ALTER TABLE `aves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `cachorros`
--
ALTER TABLE `cachorros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `chinchila`
--
ALTER TABLE `chinchila`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `coelho`
--
ALTER TABLE `coelho`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `contatos`
--
ALTER TABLE `contatos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `furao`
--
ALTER TABLE `furao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `gatos`
--
ALTER TABLE `gatos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `hamster`
--
ALTER TABLE `hamster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `instituicao`
--
ALTER TABLE `instituicao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `patos`
--
ALTER TABLE `patos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `peixes`
--
ALTER TABLE `peixes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `porcos`
--
ALTER TABLE `porcos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tartaruga`
--
ALTER TABLE `tartaruga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
