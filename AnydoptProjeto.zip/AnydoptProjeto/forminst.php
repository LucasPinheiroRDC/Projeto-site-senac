<DOCTYPE html>
    <html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Cadastro de Instituição</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="forminstcod.css">
    </head>

    <body>

        <div class="registration-form">
            <form action="forminst.php" method="post">
                <section class="get-in-touch">
                    <h1 class="title">Cadastro da Instituição</h1>
                </section>

                <div class="form-group">
                    <input type="text" class="form-control item" name="nome" placeholder="Nome da Instituição">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control item" name="cep" placeholder="CEP">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control item" name="email" placeholder="Email">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control item" name="cel" placeholder="(00) 00000-0000">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control item" name="data_cri" placeholder="00/00/0000">
                </div>

           <div class="form-group">
                    <button type="button" class="btn btn-block create-account">Criar Conta</button>
                </div>
            </form>
            <div class="social-media">
                <h5>Já tem conta?</h5>
                <div class="social-icons">
                    <a href="#">
                      <h6> Clique aqui </h6>
                </div>
            </div>
        </div>
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
        <script src="assets/js/formlogin.js"></script>
    </body>

    </html>
