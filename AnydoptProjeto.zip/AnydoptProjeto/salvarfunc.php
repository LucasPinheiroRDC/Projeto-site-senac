<?php
    include("conexao.php");
   
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    
    
    $result_func = "INSERT INTO instituicao(nome, email, senha)
                    VALUES ('$nome','$email','$senha')";
                    
    $resultado_func = mysqli_query($conn, $result_func);
   
    if(mysqli_affected_rows($conn) != 0){
                echo "Instituição cadastrada com sucesso,<p><a href=\"login.php\">clique aqui para entrar</a></p>";
            }else{
                echo "Erro ao cadastrar";
                   
                 
            }
            
?>