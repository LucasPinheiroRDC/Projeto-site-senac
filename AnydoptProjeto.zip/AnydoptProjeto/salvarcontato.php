<?php
    include("conexao.php");

    $nomeinst = $_POST["nomeinst"];
    $emailinst = $_POST["emailinst"];
    $linkinst = $_POST["linkinst"];
      
    $result_func = "INSERT INTO contatos(nomeinst, emailinst, linkinst)
                    VALUES ('$nomeinst','$emailinst','$linkinst')";
    $resultado_func = mysqli_query($conn, $result_func);
            
?>